public class FamilyMember {
    private final String name;
    private final ChoreList toDoList;

    public FamilyMember(String name) {
        this.name = name;
        this.toDoList = new ChoreList();
    }


    public void addChore(Chore chore) {
        toDoList.addChore(chore);
    }

    public void markCompleted(String choreName) {
        toDoList.markCompleted(choreName);
    }

    public void printAllChores() {
        System.out.println ("\nChores for " + name + ":" );
        toDoList.printAllChores();
        System.out.println();
    }
}


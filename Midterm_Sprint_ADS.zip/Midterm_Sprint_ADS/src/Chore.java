import java.time.LocalDate;


public class Chore {
    private final String chore;
    private String completed;
    private final int priority;
    private final LocalDate dueDate;

    public Chore(String chore, int priority, LocalDate dueDate) {
        this.chore = chore;
        this.completed = "NO";
        this.priority = priority;
        this.dueDate = dueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public int getPriority() {
        return priority;
    }

    public String getChore() {
        return chore;
    }

    public String getCompleted() {
        return completed;
    }

    public void setCompleted(String completed) {
        this.completed = completed;
    }

    @Override
    public String toString() {
        return chore + " completed: " + completed;
    }
}


/*  this print is for me personally
     * I can print off the chores list and
     * use it as a reminder of what and when chores need to be completed


    @Override
    public String toString() {
        return  chore  + " completed: ";
    }
}
*/
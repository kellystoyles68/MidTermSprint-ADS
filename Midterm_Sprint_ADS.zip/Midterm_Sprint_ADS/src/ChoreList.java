import java.time.LocalDate;

public class ChoreList {
    private Node head;

    private static class Node{
        Chore chore;
        Node next;

        Node (Chore chore) {
            this.chore = chore;
            this.next = null;
        }
    }

        public void addChore(Chore choreName) {
        Node newNode = new Node(choreName);
        if (head == null || head.chore.getPriority() > choreName.getPriority()) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.chore.getPriority() <= choreName.getPriority()) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void markCompleted(String choreName) {
        Node current = head;
        while (current != null) {
            if (current.chore.getChore().equals(choreName)){
                current.chore.setCompleted("YES");
                return;
            }
            current = current.next;
        }
    }

    public void printAllChores() {
        Node current = head;
        while (current != null) {
            System.out.println("Priority: " + current.chore.getPriority() + " - " + current.chore);
            current = current.next;
        }
    }

    public void printCompletedChores() {
        Node current = head;
        while (current != null) {
            if (current.chore.getCompleted().equals("YES")) {
                System.out.println(current.chore);
            }
            current = current.next;
        }
    }


    public void printPendingChores() {
        Node current = head;
        while (current != null) {
            if (current.chore.getCompleted().equals("NO")) {
                System.out.println(current.chore);
            }
            current = current.next;
        }
    }


        public void printChoresDueBefore(LocalDate date){
            Node current = head;
            while (current != null) {
                if (current.chore.getDueDate() != null &&
                        current.chore.getDueDate().isBefore(date)) {
                    System.out.println(current.chore);
                }
                current = current.next;
            }
        }

    }







